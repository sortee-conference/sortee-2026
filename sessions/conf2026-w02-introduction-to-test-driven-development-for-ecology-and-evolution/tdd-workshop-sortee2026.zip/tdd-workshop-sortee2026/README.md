# tdd-workshop (SORTEE 2026)

This archive contains a workshop on test-driven development for ecology and evolution. It was designed by Raphaël Scherrer, and is destined for the attendees of the 2026 conference of the Society for Open, Reliable, and Transparent Ecology and Evolution. You will find here all the files necessary for the practical, in either R (main folder) or Python (subfolder within the main folder). Please read carefully the instructions in the README files located in both these repositories (Python users: the instructions are the same as for R, so you will find the actual exercises in the R version of the README).

## Requirements

For this workshop you will need a recent version of either R or Python, as well as some specific libraries to run unit tests and measure code coverage. For R, those are: testthat and covr. For Python, it's pytest, pytest-cov and numpy. Please try to have those installed on your computer before starting the workshop (installation requirement details available in the READMEs at the links below).

## Links

You can also find the content for this workshop at the following links:

https://github.com/rscherrer/tdd-workshop
https://github.com/rscherrer/tdd-workshop-python

And follow the instructions directly from there in your browser.

## Questions? 

Email me at:

raphael.scherrer@evobio.eu
r.scherrer@rug.nl